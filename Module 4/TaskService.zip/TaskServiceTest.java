//============================================================================
// Name        : TaskServiceTest.Java
// Author      : Winnie Kwong
// Class       : CS-320 Software Test Automation & QA
// Instructor  : Professor Toledo
// Description : 4-1 Milestone: Task Service
//============================================================================

package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Task.Task;
import Task.TaskService;

class TaskServiceTest {

	private TaskService taskService;

	// Preset variables for testing unit
	@BeforeEach
	void setUp(){
		taskService = new TaskService();
		// Adding the first and second task of the array list
		Task task1 = new Task("ReadTask", "ReadingTaskID", "Executed Reading the TaskID");
		Task task2 = new Task("ReadTask2", "ReadingTaskID2", "Executed Reading the TaskID2");
		taskService.addTask(task1);
		taskService.addTask(task2);
	}

	// When testing to add a new task
	@Test
	void testAddTask() {
		Task newTask = new Task("ReadTask3", "ReadingTaskID3", "Executed Reading the TaskID3");
		taskService.addTask(newTask);
        assertEquals(newTask, taskService.getTask("ReadTask3"));
	}

	// When testing the updated name, using the first task
	@Test
	void testUpdatedName() {
		taskService.updateName("ReadTask", "ReadingCustomerID");
		Task updatedTask = taskService.getTask("ReadTask");
		assertEquals("ReadingCustomerID", updatedTask.getName());
	}
	
	// When testing the updated description, using the task
	@Test
	void testUpdatedDescription() {
		taskService.updateDescription("ReadTask", "Executed Reading the CustomerID");
		Task updatedTask = taskService.getTask("ReadTask");
		assertEquals("Executed Reading the CustomerID", updatedTask.getDescription());
	}
	
	// When the task is duplicated and not unique
	@Test
	void testTaskIDIsDupilcated() {
		// Test if contact ID exists
		assertThrows(IllegalArgumentException.class, () -> {
			Task duplicateTask = new Task("ReadTask", "ReadingTaskID", "Executed Reading the TaskID");
			taskService.addTask(duplicateTask);
		});
	}
	
	// When deleting the first task
	@Test
	void testDeleteTask() {
		taskService.deleteTask("ReadTask");
		assertNull(taskService.getTask("ReadTask"));
	}
}