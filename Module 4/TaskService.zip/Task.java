//============================================================================
// Name        : Task.Java
// Author      : Winnie Kwong
// Class       : CS-320 Software Test Automation & QA
// Instructor  : Professor Toledo
// Description : 4-1 Milestone: Task Service
//============================================================================

package Task;

public class Task {

	private final String taskID;
	private String name;
	private String description;


	public Task(String taskID, String name, String description) {
		// Ensures taskID cannot be null or more than 10 characters or it will throw illegal argument exception
		if (taskID == null || taskID.length()>10 || taskID.isEmpty()) { 
			 throw new IllegalArgumentException("Invalid task ID"); }
		 
		// Ensures name cannot be null or more than 20 characters or it will throw illegal argument exception
		if (name == null || name.length()>20 || name.isEmpty()) {
			throw new IllegalArgumentException("Invalid name"); 
		} 
		// Ensures description cannot be null or more than 50 characters or it will throw illegal argument exception
		if (description ==	null || description.length()>50 || description.isEmpty()) { 
			throw new IllegalArgumentException("Invalid descripton"); 
		}

		this.taskID = taskID;
		this.name = name;
		this.description = description;

	}
	
	
	// Getters
	public String getTaskID() {
		return taskID;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}
	
	// Mutators
	// If name is Null or empty, throw illegal argument
	public void setName(String name) {
		if (name == null || name.isEmpty()) {
			throw new IllegalArgumentException("Invalid name field");
		} 
		
		// Else if name is too long, throw illegal argument
		else if (name.length() > 20) {
			throw new IllegalArgumentException("Too long of name field");
		}
		
		// Else, sets the new first name
		else {
			this.name = name;
		}
	}

	// If description is Null or empty, throw illegal argument
	public void setDescription(String description) {
		if (description == null || description.isEmpty()) {
			throw new IllegalArgumentException("Invalid description field");
		} 
			
		// Else if description is too long, throw illegal argument
		else if (description.length() > 50) {
			throw new IllegalArgumentException("Too long of description field");
		} 
			
		// Else, sets the new description
		else {
			this.description = description;
		}
	}

}