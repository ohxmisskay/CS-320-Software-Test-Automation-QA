//============================================================================
// Name        : TaskTest.Java
// Author      : Winnie Kwong
// Class       : CS-320 Software Test Automation & QA
// Instructor  : Professor Toledo
// Description : 4-1 Milestone: Task Service
//============================================================================

package Test;

import static org.junit.Assert.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Task.Task;

class TaskTest {

	private Task task;

	// Preset variables for testing unit
	@BeforeEach
	void setUp() {
		task = new Task("ReadTask", "ReadingTaskID", "Executed Reading the TaskID");
	}
	
	// Testing if initial task was created
	@Test
	public void testTaskCreation() {
		assertEquals("ReadTask", task.getTaskID());
		assertEquals("ReadingTaskID", task.getName());
		assertEquals("Executed Reading the TaskID", task.getDescription());
	}

	// Test setters and ensure they correctly update the variables
	@Test
	void testSetters() {
		Task task = new Task("ReadTask", "ReadingTaskID", "Executed Reading the TaskID");
		task.setName("ReadCustomerID");
		assertEquals("ReadCustomerID", task.getName());

		task.setDescription("Executed Reading the CustomerID");
		assertEquals("Executed Reading the CustomerID", task.getDescription());
	}
	
	// When the task ID is too long
	@Test void testTaskIDTooLong() { 
		assertThrows(IllegalArgumentException.class, () -> { 
			new Task("This initial task ID but the test will be too long to pass", "ReadingContactID", "Executed Reading the TaskID"); 
		}); 
	}

	// When the task ID is NULL
	@Test void testTaskIDIsNull() { 
		assertThrows(IllegalArgumentException.class, () -> { 
			new Task(null, "ReadingTaskID", "Executed Reading the TaskID"); 
		}); 
	}

	// When the taskID is empty
	@Test void testTaskIDIsEmpty() { 
		assertThrows(IllegalArgumentException.class, () -> { 
			new Task("", "ReadingTaskID", "Executed Reading the TaskID"); 
		}); 
	}
	 
	
	// When the name is too long
	@Test
	void testNameTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("ReadTask", "This initialize name field it supposed to be too long", "Executed Reading the TaskID");
		});
	}

	// When the name is NULL
	@Test
	void testNameIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("ReadTask", null, "Executed Reading the TaskID");
		});
	}
	
	// When the name is empty
	@Test
	void testNameIsEmpty() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("ReadTask", "", "Executed Reading the TaskID");
		});
	}

	// When the description is too long
	@Test
	void testDescriptionTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("ReadTask", "ReadingTaskID", "This initialized description field will be too long to pass");
		});
	}

	// When the description is NULL
	@Test
	void testDescriptionIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("ReadTask", "ReadingTaskID", null);
		});
	}
	
	// When the description is empty
	@Test
	void testDescriptionIsEmpty() {
		// Ensure task ID is not null
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("ReadTask", "ReadingTaskID", "");
		});
	}

	// When the set name is NULL
	@Test 
	void testSetNameNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			task.setName(null); 
		}); 
	}
	 

	// When the set name is too long
	@Test
	void testSetNameIsTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			task.setName("This is the name field but it will fail because it is too long");
		});
	}

	// When the set name is empty
	@Test
	void testSetNameIsEmpty() {
		assertThrows(IllegalArgumentException.class, () -> {
			task.setName("");
		});
	}

	// When the set description is NULL
	@Test
	void testSetDescriptionIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			task.setDescription(null);
		});
	}

	// When the set description is empty
	@Test
	void testSetDescriptionIsEmpty() {
		assertThrows(IllegalArgumentException.class, () -> {
			task.setDescription("");
		});
	}

	// When the set description is too long
	@Test
	void testSetDescriptionIsTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			task.setDescription("This is where we need to include a description field but the test will be too long to pass");
		});
	}
}