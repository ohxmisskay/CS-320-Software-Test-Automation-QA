//============================================================================
// Name        : TaskService.Java
// Author      : Winnie Kwong
// Class       : CS-320 Software Test Automation & QA
// Instructor  : Professor Toledo
// Description : 4-1 Milestone: Task Service
//============================================================================

package Task;

import java.util.ArrayList;
import java.util.List;

public class TaskService {
	private List<Task> task = new ArrayList<>();

	// Function to add a task with a unique ID
	public void addTask(Task taskLoop) {
		if (isTaskIDUnique(taskLoop.getTaskID())) {
			task.add(taskLoop);
		} else {
			throw new IllegalArgumentException("TaskID already exists");
		}
	}

	// Function to delete a task by task ID string
	public void deleteTask(String taskID) {
		// Find the task with the given task ID and remove it
		task.removeIf(task -> task.getTaskID().equals(taskID));
	}
	
	// Function to change the name. User must match taskID first
	public void updateName(String taskID, String name) {
		for (Task task : task) {
			if (task.getTaskID().equals(taskID)) {
				// Update name if not null
				if (name != null) {
					task.setName(name);
				}
				break;
			}
			
		} 
	}
		
	// Function to change the description. User must match taskID first
	public void updateDescription(String taskID, String description) {
		for (Task task : task) {
			if (task.getTaskID().equals(taskID)) {
				// Update description if not null
				if (description != null) {
					task.setDescription(description);
				}
				break;
			}
		}
	}
	
	// Searches through task list for desired task
	public Task getTask(String taskID) {
		for (Task task : task) {
			// If the task ID matches
			if (task.getTaskID().equals(taskID)) {
				// Returns the task
				return task;
			}
		}
		// Returns the task to be null
		return null; 
	}
	
	// Checks for duplicate task and returns Boolean
	private boolean isTaskIDUnique(String taskID) {
		for (Task task : task) {
			if (task.getTaskID().equals(taskID)) {
				// Not unique
				return false; 
			}
		}
		// Else it is unique
		return true; 
	}
}
