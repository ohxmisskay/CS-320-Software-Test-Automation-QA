//============================================================================
// Name        : AppointmentService.Java
// Author      : Winnie Kwong
// Class       : CS-320 Software Test Automation & QA
// Instructor  : Professor Toledo
// Description : 5-1 Milestone: Appointment Service
//============================================================================

package Appointment;

import java.util.ArrayList;
import java.util.List;

import java.time.LocalDate;


public class AppointmentService {
	private List<Appointment> appointment = new ArrayList<>();

	// Function to add a appointment with a unique ID
	public void addAppointment(Appointment appointmentLoop) {
		if (isAppointmentIDUnique(appointmentLoop.getAppointmentID())) {
			appointment.add(appointmentLoop);
		} else {
			throw new IllegalArgumentException("AppointmentID already exists");
		}
	}

	// Function to delete a appointment by appointment ID string
	public void deleteAppointment(String appointmentID) {
		// Find the appointment with the given appointment ID and remove it
		appointment.removeIf(appointment -> appointment.getAppointmentID().equals(appointmentID));
	}

	// Function to change the date. User must match appointment ID first
	public void updateAppointmentDate(String appointmentID, LocalDate appointmentDate) {
		for (Appointment appointment : appointment) {
			if (appointment.getAppointmentID().equals(appointmentID)) {
				// Update date if not null
				if (appointmentDate != null) {
					appointment.setAppointmentDate(appointmentDate);
				}
				else {
					throw new IllegalArgumentException("Appointment Date is incorrect");
				}

			} 
		}
	}

	// Function to change the description. User must match appointment ID first
	public void updateAppointmentDescription(String appointmentID, String appointmentDescription) {
		for (Appointment appointment : appointment) {
			if (appointment.getAppointmentID().equals(appointmentID)) {
				// Update description if not null
				if (appointmentDescription != null) {
					appointment.setAppointmentDescription(appointmentDescription);
				}
				else {
					throw new IllegalArgumentException("Appointment Description is incorrect");
				}
			}
		}
	}

	// Searches through appointment list for desired appointment
	public Appointment getAppointment(String appointmentID) {
		for (Appointment appointment : appointment) {
			// If the appointment ID matches
			if (appointment.getAppointmentID().equals(appointmentID)) {
				// Returns the appointment
				return appointment;
			}
		}
		// Returns the appointment to be null
		return null; 
	}

	// Checks for duplicate appointment and returns Boolean
	private boolean isAppointmentIDUnique(String appointmentID) {
		for (Appointment appointment : appointment) {
			if (appointment.getAppointmentID().equals(appointmentID)) {
				// Not unique
				return false; 
			}
		}
		// Else it is unique
		return true; 
	}
}
