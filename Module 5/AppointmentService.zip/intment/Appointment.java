//============================================================================
// Name        : Appointment.Java
// Author      : Winnie Kwong
// Class       : CS-320 Software Test Automation & QA
// Instructor  : Professor Toledo
// Description : 5-1 Milestone: Appointment Service
//============================================================================

package Appointment;

import java.time.LocalDate;

public class Appointment {
	
	private final String appointmentID;
	private LocalDate appointmentDate;
	private String appointmentDescription;

	public Appointment(String appointmentID, LocalDate appointmentDate, String appointmentDescription) {
		// Ensures appointmentID cannot be null or more than 10 characters or it will throw illegal argument exception
		if (appointmentID == null || appointmentID.length()>10 || appointmentID.isBlank()) { 
			 throw new IllegalArgumentException("Invalid appointment ID"); }
		 
		// Ensures date cannot be in the past and cannot be null or it will throw
		if (appointmentDate == null || appointmentDate.isBefore(LocalDate.now())) {
			throw new IllegalArgumentException("Invalid appointment date.");
		}
		
		// Ensures description cannot be null or more than 50 characters or it will throw illegal argument exception
		if (appointmentDescription ==	null || appointmentDescription.length()>50 || appointmentDescription.isBlank()) { 
			throw new IllegalArgumentException("Invalid descripton"); 
		}

		this.appointmentID = appointmentID;
		this.appointmentDate = appointmentDate;
		this.appointmentDescription = appointmentDescription;

	}
	
	
	// Getters
	public String getAppointmentID() {
		return appointmentID;
	}

	public LocalDate getAppointmentDate() {
		return appointmentDate;
	}

	public String getAppointmentDescription() {
		return appointmentDescription;
	}
	
	// Mutators
	// If name is Null or empty, throw illegal argument
	public void setAppointmentDate(LocalDate appointmentDate) {
		if (appointmentDate == null || appointmentDate.isBefore(LocalDate.now())) {
			throw new IllegalArgumentException("Invalid date field");
		} 
		
		// Else, sets the new date
		else {
			this.appointmentDate = appointmentDate;
		}
	}

	// If description is Null or empty, throw illegal argument
	public void setAppointmentDescription(String appointmentDescription) {
		if (appointmentDescription == null || appointmentDescription.isEmpty()) {
			throw new IllegalArgumentException("Invalid description field");
		} 
			
		// Else if description is too long, throw illegal argument
		else if (appointmentDescription.length() > 50) {
			throw new IllegalArgumentException("Too long of description field");
		} 
			
		// Else, sets the new description
		else {
			this.appointmentDescription = appointmentDescription;
		}
	}

}
