//============================================================================
// Name        : AppointmentServiceTest.Java
// Author      : Winnie Kwong
// Class       : CS-320 Software Test Automation & QA
// Instructor  : Professor Toledo
// Description : 5-1 Milestone: Appointment Service
//============================================================================

package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Appointment.Appointment;
import Appointment.AppointmentService;


class AppointmentServiceTest {

	private AppointmentService appointmentService;

	LocalDate appointmentDate = LocalDate.now();
	LocalDate appointmentDate2 = LocalDate.of(2023, 10, 01);
	LocalDate appointmentDate3 = LocalDate.of(2023, 10, 28);

	// Preset variables for testing unit
	@BeforeEach
	void setUp(){
		appointmentService = new AppointmentService();
		// Adding the first and second appointment of the array list
		Appointment appointment1 = new Appointment("Dentist", appointmentDate, "Teeth Cleaning");
		Appointment appointment2 = new Appointment("Homework", appointmentDate2, "Module 5 Assignments Due");
		appointmentService.addAppointment(appointment1);
		appointmentService.addAppointment(appointment2);
	}

	// When testing to add a new appointment
	@Test
	void testAddAppointment() {
		Appointment newAppointment = new Appointment("Pumpkin", appointmentDate3, "Family Fun Pumpkin Patch");
		appointmentService.addAppointment(newAppointment);
		assertEquals(newAppointment, appointmentService.getAppointment("Pumpkin"));
	}

	// When testing the updating date by 14 days, using the first appointment
	@Test
	void testUpdatedAppointmentDate() {
		appointmentService.updateAppointmentDate("Dentist", appointmentDate.plusDays(14));
		Appointment updatedAppointment = appointmentService.getAppointment("Dentist");
		assertEquals(appointmentDate.plusDays(14), updatedAppointment.getAppointmentDate());
	}

	// When testing the updated date is null, using the first appointment
	@Test
	void testUpdatedAppointmentDateisNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			appointmentService.updateAppointmentDate("Dentist", null);
		});
	}

	// When testing the updated description, using the first appointment
	@Test
	void testUpdatedAppointmentDescription() {
		appointmentService.updateAppointmentDescription("Dentist", "Teeth cleaning and root canal");
		Appointment updatedAppointment = appointmentService.getAppointment("Dentist");
		assertEquals("Teeth cleaning and root canal", updatedAppointment.getAppointmentDescription());
	}
	
	// When testing the updated description is null, using the first appointment
		@Test
		void testUpdatedAppointmentDescriptionisNull() {
			assertThrows(IllegalArgumentException.class, () -> {
				appointmentService.updateAppointmentDescription("Dentist", null);
			});
		}

	// When the appointment is duplicated and not unique
	@Test
	void testAppointmentIDIsDupilcated() {
		// Test if appointment ID exists
		assertThrows(IllegalArgumentException.class, () -> {
			Appointment duplicateAppointment = new Appointment("Dentist", appointmentDate, "Teeth Cleaning");
			appointmentService.addAppointment(duplicateAppointment);
		});
	}

	// When deleting the first appointment
	@Test
	void testDeleteAppointment() {
		appointmentService.deleteAppointment("Dentist");
		assertNull(appointmentService.getAppointment("Dentist"));
	}
}
