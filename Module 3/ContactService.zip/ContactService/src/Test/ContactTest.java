//============================================================================
// Name        : ContactTest.Java
// Author      : Winnie Kwong
// Class       : CS-320 Software Test Automation & QA
// Instructor  : Professor Toledo
// Description : 3-2 Milestone: Contact Service
//============================================================================

package Test;

import static org.junit.Assert.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ContactService.Contact;

public class ContactTest {

	private Contact contact;

	// Preset variables for testing unit
	@BeforeEach
	void setUp() {
		contact = new Contact("1", "Saul", "Goodman", "5055034455", "308 Negra Arroyo Lane");
	}
	
	// Testing if initial Contact was created
	@Test
	public void testContactCreation() {
		assertEquals("1", contact.getContactID());
		assertEquals("Saul", contact.getFirstName());
		assertEquals("Goodman", contact.getLastName());
		assertEquals("5055034455", contact.getNumber());
		assertEquals("308 Negra Arroyo Lane", contact.getAddress());
	}

	// Test setters and ensure they correctly update the variables
	@Test
	void testSetters() {
		Contact contact = new Contact("1", "Saul", "Goodman", "5055034455", "308 Negra Arroyo Lane");
		contact.setFirstName("Walter");
		assertEquals("Walter", contact.getFirstName());

		contact.setLastName("White");
		assertEquals("White", contact.getLastName());

		contact.setNumber("1234567890");
		assertEquals("1234567890", contact.getNumber());

		contact.setAddress("123 Fake Street");
		assertEquals("123 Fake Street", contact.getAddress());
	}
	
	// When the first name is too long
	@Test
	void testFirstNameTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "SaulGoodman", "Goodman", "5055034455", "308 Negra Arroyo Lane");
		});
	}

	// When the first name is NULL
	@Test
	void testFirstNameIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", null, "Goodman", "5055034455", "308 Negra Arroyo Lane");
		});
	}
	
	// When the first name is empty
	@Test
	void testFirstNameIsEmpty() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "", "Goodman", "5055034455", "308 Negra Arroyo Lane");
		});
	}

	// When the Last name is too long
	@Test
	void testLastNameTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Saul", "'SaulGoodman", "5055034455", "308 Negra Arroyo Lane");
		});
	}

	// When the last name is NULL
	@Test
	void testLastNameIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Saul", null, "5055034455", "308 Negra Arroyo Lane");
		});
	}
	
	// When the last name is empty
	@Test
	void testLastNameIsEmpty() {
		// Ensure contact ID is not null
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Saul", "", "5055034455", "308 Negra Arroyo Lane");
		});
	}

	// When the phone is not exactly 10 characters
	@Test
	void testNumberNotTenCharacters() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Saul", "'Goodman", "12345", "308 Negra Arroyo Lane");
		});
	}

	// When the phone number is NULL
	@Test
	void testNumberIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Saul", "Goodman", null, "308 Negra Arroyo Lane");
		});
	}
	
	// When the phone number is empty
	@Test
	void testNumberIsEmpty() {
		// Ensure contact ID is not null
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Saul", "Goodman", "", "308 Negra Arroyo Lane");
		});
	}

	// When the address is too long
	@Test
	void testAddressTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Saul", "'Goodman", "5055034455", "3828 Piermont Dr, Albuquerque, NM");
		});
	}

	// When the address is NULL
	@Test
	void testAddressIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Saul", "Goodman", "5055034455", null);
		});
	}
	
	// When the address is empty
	@Test
	void testAddressIsEmpty() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Saul", "Goodman", "5055034455", "");
		});
	}
	
	// When the set first name is NULL
	@Test 
	void testSetFirstNameNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName(null); 
		}); 
	}
	 

	// When the set first name is too long
	@Test
	void testSetFirstNameisTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName("SaulGoodman");
		});
	}

	// When the set first name is empty
	@Test
	void testSetFirstNameisEmpty() {
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName("");
		});
	}

	// When the set last name is NULL
	@Test
	void testSetLastNameisNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName(null);
		});
	}

	// When the set last name is empty
	@Test
	void testSetLastNameisEmpty() {
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName("");
		});
	}

	// When the set last name is too long
	@Test
	void testSetLastNameisTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName("SaulGoodman");
		});
	}

	// When the set phone number is NULL
	@Test
	void testSetNumberisNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setNumber(null);
		});
	}

	// When the set phone number is empty
	@Test
	void testSetNumberisEmpty() {
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setNumber("");
		});
	}

	// When the set phone number is not exactly 10 characters
	@Test
	void testSetNumberNotTenCharacters() {
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setNumber("12345678910");
		});
	}

	// When the set address is NULL
	@Test
	void testSetAddressisNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress(null);
		});
	}

	// When the set address is empty
	@Test
	void testSetAddressisEmpty() {
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress("");
		});
	}
	
	// When the set address is too long
	@Test
	void testSetAddressTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress("3828 Piermont Dr, Albuquerque, NM");
		});
	}

}