//============================================================================
// Name        : ContactServiceTest.Java
// Author      : Winnie Kwong
// Class       : CS-320 Software Test Automation & QA
// Instructor  : Professor Toledo
// Description : 3-2 Milestone: Contact Service
//============================================================================

package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ContactService.Contact;
import ContactService.ContactService;

public class ContactServiceTest {

	private ContactService contactService;

	// Preset variables for testing unit
	@BeforeEach
	void setUp(){
		contactService = new ContactService();
		// Adding the first and second contact of the array list
        Contact contact1 = new Contact("1", "Saul", "Goodman", "5055034455", "308 Negra Arroyo Lane");
        Contact contact2 = new Contact("2", "Homer", "Simpson", "5555557334", "742 Evergreen Terrace");
        contactService.addContact(contact1);
        contactService.addContact(contact2);
	}

	// When testing to add a new contact
	@Test
	void testAddContact() {
		Contact newContact = new Contact("3", "Dwight", "Schrute ", "8009843672", "Rural Rt. 6");
        contactService.addContact(newContact);
        assertEquals(newContact, contactService.getContact("3"));
	}

	// When testing the updated first name, using the first contact
	@Test
	void testUpdatedFirstName() {
		contactService.updateContact("1", "Walter", null, null, null);
		Contact updatedContact = contactService.getContact("1");
		assertEquals("Walter", updatedContact.getFirstName());
	}

	// When testing the updated last name, using the first contact
	@Test
	void testUpdatedLastName() {
		contactService.updateContact("1", null, "White", null, null);

		Contact updatedContact = contactService.getContact("1");
		assertEquals("White", updatedContact.getLastName());
	}

	// When testing the updated phone number, using the first contact
	@Test
	void testUpdatedNumber() {
		contactService.updateContact("1", null, null, "5555555555", null);

		Contact updatedContact = contactService.getContact("1");
		assertEquals("5555555555", updatedContact.getNumber());
	}

	// When testing the updated address, using the first contact
	@Test
	void testUpdatedAddress() {
		contactService.updateContact("1", null, null, null, "3828 Piermont Dr");

		Contact updatedContact = contactService.getContact("1");
		assertEquals("3828 Piermont Dr", updatedContact.getAddress());
	}
	
	// When the contact is duplicated and not unique
	@Test
	void testContactIDIsDupilcated() {
		// Test if contact ID exists
		assertThrows(IllegalArgumentException.class, () -> {
			Contact duplicateContact = new Contact("1", "Saul", "Goodman", "5055034455", "308 Negra Arroyo Lane");
			contactService.addContact(duplicateContact);
		});
	}
	
	// When deleting the first contact
	@Test
	void testDeleteContact() {
		contactService.deleteContact("1");

		assertNull(contactService.getContact("1"));
	}
}