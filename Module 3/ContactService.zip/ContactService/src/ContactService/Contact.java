//============================================================================
// Name        : Contact.Java
// Author      : Winnie Kwong
// Class       : CS-320 Software Test Automation & QA
// Instructor  : Professor Toledo
// Description : 3-2 Milestone: Contact Service
//============================================================================

package ContactService;

public class Contact {
	private final String contactId;
	private String firstName;
	private String lastName;
	private String number;
	private String address;

	public Contact(String contactID, String firstName, String lastName, String number, String address) {
		
		// Ensures first name cannot be null or more than 10 characters or it will throw illegal argument exception
		if (firstName == null || firstName.length()>10 || firstName.isEmpty()) {
			throw new IllegalArgumentException("Invalid first name"); 
		} 
		// Ensures last name cannot be null or more than 10 characters or it will throw illegal argument exception
		if (lastName ==	null || lastName.length()>10 || lastName.isEmpty()) { 
			throw new IllegalArgumentException("Invalid last name"); 
		}
		// Ensures phone number cannot be null or more than 10 characters or it will throw illegal argument exception
		if (number == null || number.length() != 10 || number.isEmpty()) { 
			throw new IllegalArgumentException("Invalid phone number"); 
		} 
		// Ensures address cannot be null or more than 30 characters or it will throw illegal argument exception
		if (address == null || address.length()>30|| address.isEmpty()) { 
			throw new IllegalArgumentException("Invalid address");
		}
				
		this.contactId = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.number = number;
		this.address = address;
	}
	
	

	// Getters
	public String getContactID() {
		return contactId;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getNumber() {
		return number;
	}

	public String getAddress() {
		return address;
	}
	
	// Mutators
		// If FirstName is Null or empty, throw illegal argument
		public void setFirstName(String firstName) {
			if (firstName == null || firstName.isEmpty()) {
				throw new IllegalArgumentException("Invalid first name");

			// Else if first name is too long, throw illegal argument 
			} else if (firstName.length() > 10) {
				throw new IllegalArgumentException("Too long of first name");
				
			// Else, sets the new first name
			} else {
				this.firstName = firstName;
			}
		}

		// If lastName is Null or empty, throw illegal argument
		public void setLastName(String lastName) {
			if (lastName == null || lastName.isEmpty()) {
				throw new IllegalArgumentException("Invalid last name");
				
			// Else if last name is too long, throw illegal argument 
			} else if (lastName.length() > 10) {
				throw new IllegalArgumentException("Too long of last name");
				
			// Else, sets the new last name
			} else {
				this.lastName = lastName;
			}
		}

		// If phone number is Null or empty or not 10 characters, throw illegal argument
		public void setNumber(String number) {
			if (number == null || number.isEmpty() || number.length() != 10) {
				throw new IllegalArgumentException("Invalid phone name");
			
			// Else, set phone number to new number
			} else {
				this.number = number;
			}
		}

		// If address is Null or empty, throw illegal argument
		public void setAddress(String address) {
			if (address == null || address.isEmpty()) {
				throw new IllegalArgumentException("Invalid address");
				
			// Else if address or more than 30 characters, throw illegal argument
			} else if (address.length() > 30) {
				throw new IllegalArgumentException("Too long of address");
				
			// Else set address to new address
			} else {
				this.address = address;
			}
		}
}