//============================================================================
// Name        : ContactService.Java
// Author      : Winnie Kwong
// Class       : CS-320 Software Test Automation & QA
// Instructor  : Professor Toledo
// Description : 3-2 Milestone: Contact Service
//============================================================================

package ContactService;

import java.util.ArrayList;
import java.util.List;


public class ContactService {
	private List<Contact> contacts = new ArrayList<>();

	// Function to add a contact with a unique ID
	public void addContact(Contact contactLoop) {
		if (isContactIDUnique(contactLoop.getContactID())) {
			contacts.add(contactLoop);
		} else {
			throw new IllegalArgumentException("Contact ID is not unique.");
		}
	}

	// Function to delete a contact by contact ID string
	public void deleteContact(String contactID) {
		// Find the contact with the given contactID and remove it
		contacts.removeIf(contact -> contact.getContactID().equals(contactID));
	}

	// Update contact variables by contact ID string
	public void updateContact(String contactID, String firstName, String lastName, String phone, String address) {
		for (Contact contact : contacts) {
			if (contact.getContactID().equals(contactID)) {
				// Update the variables if not null
				if (firstName != null) {
					contact.setFirstName(firstName);
				}
				if (lastName != null) {
					contact.setLastName(lastName);
				}
				if (phone != null) {
					contact.setNumber(phone);
				}
				if (address != null) {
					contact.setAddress(address);
				}
				break;
			}
		}
	}
	// Searches through ContactList for desired Contact
	public Contact getContact(String contactID) {
		for (Contact contact : contacts) {
			// If the contact ID matches
			if (contact.getContactID().equals(contactID)) {
				// Returns the contact
				return contact;
			}
		}
		// Returns the contact to be null
		return null; 
	}
	// Checks for duplicate Contact and returns Boolean
	private boolean isContactIDUnique(String contactID) {
		for (Contact contact : contacts) {
			if (contact.getContactID().equals(contactID)) {
				// Not unique
				return false; 
			}
		}
		// Else it is unique
		return true; 
	}
}